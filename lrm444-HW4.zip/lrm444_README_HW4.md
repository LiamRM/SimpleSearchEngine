### How to run the program
The program file ```hw4.py``` must be in the same directory as the two files ```cran.qry``` (which contains the collection of queries) and ```cran.all.1400```.